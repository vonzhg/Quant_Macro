---
trigger: before reporting any numerical result
scope: project
priority: critical
---

# Verification Protocol

**Always run code before reporting results.** Never present untested output.

## Before Reporting Any Result

1. **Execute the script** — It must run without errors
2. **Check for NaN/Inf** — No NaN or Inf in value functions, policy functions, or distributions
3. **Check convergence** — The algorithm must have converged (not hit max iterations)
4. **Compare to benchmarks** — Results must match known values within tolerance

## Benchmark Checks

### Deterministic Model (v0)
- Steady-state capital: compare to analytical formula `k_ss = (alpha / (1/beta - 1 + delta))^(1/(1-alpha))`
- Steady-state consumption: `c_ss = k_ss^alpha - delta * k_ss`
- Value function at steady state: `V(k_ss) = u(c_ss) / (1 - beta)`

### Income Risk Model (v1)
- Policy function monotonicity: `a'(a, y)` weakly increasing in `a` for each `y`
- Policy function: borrowers save less — `a'(a, y_low) ≤ a'(a, y_high)` for all `a`
- Euler equation residuals: max absolute residual < 1e-4

### Stationary Distribution (v2)
- Distribution sums to 1: `sum(mu) = 1.0` within machine precision
- All entries non-negative: `min(mu) ≥ 0`
- Market clearing: `|K_supply - K_demand| < 1e-4`
- Interest rate: `r < 1/beta - 1` (incomplete markets ⇒ capital overaccumulation)

## What to Do When a Check Fails

1. Print the failing value and the expected benchmark
2. Do NOT proceed to the next version
3. Diagnose: is it a grid issue, algorithm bug, or parameter error?
4. Fix and re-run the full verification suite
