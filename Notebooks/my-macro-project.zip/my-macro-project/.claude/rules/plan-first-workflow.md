---
trigger: before implementing any non-trivial model change
scope: project
priority: high
---

# Plan-First Workflow

Before writing code for any non-trivial task, create a plan.

## When to Plan

- Adding a new model version (v0 → v1 → v2)
- Changing the solution algorithm (e.g., switching from VFI to EGM)
- Modifying the economic environment (preferences, technology, market structure)
- Debugging a convergence failure

## Plan Format

Save plans to `quality_reports/plans/` with the naming convention:
`plan-{version}-{description}.md`

Example: `plan-v1-income-risk.md`

## Plan Contents

1. **Goal** — What this version adds or changes
2. **Algorithm** — Key equations and solution steps
3. **Benchmarks** — Expected values to validate against
4. **Dependencies** — What must be working first (previous version passing all tests)
5. **Files to create/modify** — List of scripts and outputs

## Rule

Never start implementing a new model version without a saved plan. The plan is the contract between intent and implementation.
