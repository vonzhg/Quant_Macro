---
trigger: after any code implementation
scope: project
priority: critical
---

# Orchestrator Protocol

Every code change follows the loop: **Implement → Verify → Review → Fix → Score**.

## The Loop

```
┌─────────────┐
│  Implement   │  Write or modify code in scripts/
└──────┬───────┘
       ▼
┌─────────────┐
│   Verify     │  Run code via verifier agent — check it executes, converges, no NaN
└──────┬───────┘
       ▼
┌─────────────┐
│   Review     │  Send to code-reviewer AND domain-reviewer agents
└──────┬───────┘
       ▼
┌─────────────┐
│    Fix       │  Address findings by severity (Critical → High → Medium)
└──────┬───────┘
       ▼
┌─────────────┐
│   Score      │  Assign quality score; decide if another loop is needed
└─────────────┘
```

## Agent Selection

| Step | Agent | Mode |
|------|-------|------|
| Verify | `verifier` | EXECUTE — runs scripts, checks output |
| Review (code) | `code-reviewer` | READ-ONLY — inspects code quality |
| Review (econ) | `domain-reviewer` | READ-ONLY — checks economic correctness |

## Fix Priority

1. **Critical** — Code doesn't run, wrong equilibrium, NaN in output → fix immediately
2. **High** — Fails benchmark by >5%, missing convergence check → fix before next version
3. **Medium** — Style issues, missing comments, suboptimal vectorization → fix if time permits
4. **Low** — Suggestions for future improvement → note in MEMORY.md

## Loop Limits

- Maximum **3 fix iterations** per implementation step
- If still failing after 3 loops, stop and reassess the algorithm design
- Each loop should show measurable improvement in the score

## Quality Score

Rate each version on: Correctness (0-10), Code Quality (0-10), Documentation (0-10).
Minimum to proceed to next version: Correctness ≥ 8, Code Quality ≥ 6, Documentation ≥ 5.
