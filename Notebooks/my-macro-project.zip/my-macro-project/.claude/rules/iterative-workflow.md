---
trigger: when building or extending a model
scope: project
priority: critical
---

# Iterative Workflow

**Start simple, validate, extend.** This is the core principle.

## Version Progression

```
Version 0 (Deterministic)
    │   ✓ All benchmarks pass
    ▼
Version 1 (Add Key Feature)
    │   ✓ All benchmarks pass
    ▼
Version 2 (Full Model)
    │   ✓ All benchmarks pass
    ▼
  Done
```

## For the Aiyagari Model

| Version | What It Adds | Validation Gate |
|---------|-------------|-----------------|
| v0 | Deterministic savings problem | Analytical steady state matches within 1e-6 |
| v1 | Idiosyncratic income risk | Policy functions are monotone; Euler equation residuals < 1e-4 |
| v2 | Stationary distribution + GE | Distribution sums to 1; market clearing < 1e-4; K matches Aiyagari (1994) |

## Rules

1. **Never skip a version.** Even if v0 seems trivial, implement and validate it. It catches grid, interpolation, and algorithm bugs early.

2. **Never skip validation between versions.** The previous version must pass ALL benchmarks before you extend. A bug carried forward compounds.

3. **Each version gets its own script.** `aiyagari_v0.py`, `aiyagari_v1.py`, `aiyagari_v2.py`. Do not overwrite — keep the simple versions as regression tests.

4. **Document what changed.** At the top of each script, note what this version adds relative to the previous one.

5. **Shared utilities are OK.** Grid construction, Tauchen discretization, and plotting helpers can live in `scripts/utils.py` and be imported by all versions.
