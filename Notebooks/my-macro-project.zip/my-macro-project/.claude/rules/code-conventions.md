---
trigger: when writing or reviewing code
scope: project
priority: medium
---

# Code Conventions

## Reproducibility

- **Always set the random seed:** `np.random.seed(42)` at the top of every script
- **No hardcoded absolute paths:** Use `os.path.join()` and relative paths from the project root
- **Pin key parameters:** Define all model parameters in a dictionary or dataclass at the top of the script

## Naming

- **Value function:** `V`
- **Consumption policy:** `c_pol`
- **Savings policy:** `a_pol`
- **Transition matrix:** `Pi`
- **Stationary distribution:** `mu`
- **Asset grid:** `a_grid`
- **Income grid:** `y_grid`
- **State variables:** `(a, y)` — assets and income

## Style

- Use NumPy vectorized operations over explicit loops where possible
- Comment key equations with their economic meaning:
  ```python
  # Budget constraint: c + a' = (1 + r) * a + y
  c = (1 + r) * a_grid[:, None] + y_grid[None, :] - a_prime
  ```
- Group code into clear sections: Parameters, Grids, Solution, Simulation, Output

## Output

- Save all figures to `output/` with descriptive names: `aiyagari_v1_policy.png`
- Save numerical results to `output/` as `.npz` or `.csv`
- Print a summary table of key results at the end of each script
- Use `matplotlib` for figures; set `figsize=(10, 6)` and include axis labels and titles

## Script Structure

```python
"""
Aiyagari Model — Version X: [Description]
Changes from v(X-1): [What's new]
"""
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path

# ── Parameters ──────────────────────────────────────
# ── Grids ───────────────────────────────────────────
# ── Solution Algorithm ──────────────────────────────
# ── Diagnostics & Benchmarks ────────────────────────
# ── Figures ─────────────────────────────────────────
# ── Save Results ────────────────────────────────────
```
