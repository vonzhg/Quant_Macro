---
name: Validate
description: Run benchmarks, check convergence, verify economic correctness
user_invocable: true
command: validate
arguments:
  - name: model
    description: Which model to validate (e.g., aiyagari, rbc)
    required: true
  - name: version
    description: Which version to validate (v0, v1, v2)
    required: true
---

# Validate Skill

Run the full validation suite for a model version. This skill orchestrates the verifier agent and both reviewer agents.

## Steps

### 1. Run the Script
Execute `scripts/{model}_{version}.py` using the verifier agent:
- Must run without errors
- Must converge (not hit max iterations)
- Must produce output files in `output/`

### 2. Check Benchmarks
Compare results against reference values in `skills/solve-model/references/{model}-guide.md`:

**Version 0 (Deterministic):**
- Steady-state values match analytical formulas within 1e-6
- Policy function crosses 45-degree line at steady state

**Version 1 (Income Risk):**
- Policy functions are monotone in both `a` and `y`
- Euler equation residuals < 1e-4 at non-constrained points
- Borrowing constraint binds for low `(a, y)` states

**Version 2 (Stationary Distribution):**
- `sum(mu) = 1.0` within 1e-10
- `min(mu) >= 0`
- Market clearing: `|K_s - K_d| < 1e-4`
- `r < 1/beta - 1`

### 3. Economic Review
Send code to the domain reviewer agent:
- Equations match the model specification
- Equilibrium conditions are correct
- Comparative statics have correct signs

### 4. Code Review
Send code to the code reviewer agent:
- Vectorized where possible
- Numerically stable
- Follows project conventions

### 5. Report
Produce a validation report summarizing:
```
VALIDATION REPORT — {model} {version}
======================================
Execution:        [PASS/FAIL]
Convergence:      [PASS/FAIL]  ({N} iterations, residual = {x})
Benchmarks:       [PASS/FAIL]  (list each check)
Economic Review:  [PASS/FAIL]  (summary of findings)
Code Review:      [PASS/FAIL]  (summary of findings)

Overall:          [PASS/FAIL]
Ready for next version: [YES/NO]
```

Save the report to `quality_reports/{model}_{version}_validation.md`.

## Gate Rule

A version passes validation ONLY if ALL checks pass. If any check fails, the version is NOT ready for extension. Fix the issues and re-validate.
