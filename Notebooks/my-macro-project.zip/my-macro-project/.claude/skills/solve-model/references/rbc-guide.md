# RBC Model — Algorithm Reference

## Model Environment

- Representative agent, infinite horizon
- Preferences: `u(c) = c^(1-sigma) / (1-sigma)`, `sigma = 2`
- Technology: `Y = z * K^alpha * L^(1-alpha)`, `alpha = 0.36`
- Capital law of motion: `K' = (1-delta) * K + I`, `delta = 0.025`
- Discount factor: `beta = 0.99`

---

## Version 0: Deterministic Steady State

### Algorithm
No computation needed — this is analytical.

### Steady-State Formulas
```
r_ss   = 1/beta - 1
K_ss   = (alpha / (r_ss + delta))^(1/(1-alpha))
Y_ss   = K_ss^alpha
C_ss   = Y_ss - delta * K_ss
I_ss   = delta * K_ss
V_ss   = u(C_ss) / (1 - beta)
```

### Benchmark Values (sigma=2, alpha=0.36, beta=0.99, delta=0.025)
| Variable | Value |
|----------|-------|
| `r_ss` | 0.01010 |
| `K_ss` | 11.812 |
| `Y_ss` | 1.1568 |
| `C_ss` | 0.8615 |
| `V_ss` | -68.12 (approx) |

### Validation
- Verify Euler equation holds: `u'(C_ss) = beta * (1 + r_ss) * u'(C_ss)` → `1 = beta * (1 + r_ss)`
- Verify goods market clearing: `Y_ss = C_ss + I_ss`

---

## Version 1: Stochastic TFP

### Changes from v0
- TFP follows AR(1): `log(z') = rho * log(z) + epsilon`, `epsilon ~ N(0, sigma_z^2)`
- Parameters: `rho = 0.95`, `sigma_z = 0.007`

### Algorithm: Value Function Iteration
1. Discretize TFP using **Tauchen method** with `N_z = 7` grid points, `m = 3` std deviations
2. Create capital grid: `N_k = 200` points, `k_min = 0.5 * K_ss`, `k_max = 1.5 * K_ss`
3. Initialize `V(k, z) = u(C_ss) / (1 - beta)` for all `(k, z)`
4. Iterate on Bellman equation:
   ```
   V(k, z) = max_{k'} { u(z * k^alpha - delta*k + (1-delta)*k - k') + beta * E[V(k', z') | z] }
   ```
   Simplify: `c = z * k^alpha + (1-delta)*k - k'`, require `c > 0`
5. Convergence: `sup |V_new - V_old| < 1e-8`
6. Howard improvement: every 25 VFI iterations, do 50 policy iteration steps

### Tauchen Discretization
- Grid: `z_grid = exp(y_grid)` where `y_grid` spans `[-m*sigma_y, +m*sigma_y]`
- Unconditional std: `sigma_y = sigma_z / sqrt(1 - rho^2)`
- Transition matrix `Pi[i,j]` using normal CDF at midpoints

### Benchmark Values
| Variable | Value |
|----------|-------|
| `E[K]` | ≈ 11.81 (close to deterministic) |
| `std(K)` | small, ~0.08 |
| `std(Y)/std(z)` | ≈ 1.4 (output more volatile than TFP) |
| `corr(C, Y)` | > 0.95 (consumption tracks output) |

### Validation
- Mean capital close to deterministic `K_ss`
- Policy function `k'(k, z)` increasing in both `k` and `z`
- Value function `V(k, z)` concave in `k` for each `z`

---

## Version 2: Variable Labor Supply

### Changes from v1
- Preferences: `u(c, l) = (c^(1-sigma)) / (1-sigma) - chi * l^(1+1/eta) / (1+1/eta)`
- Labor is now a choice: `eta = 1.0` (Frisch elasticity), `chi` calibrated to `L_ss = 1`
- Production: `Y = z * K^alpha * L^(1-alpha)`

### Algorithm
1. Same as v1, but now maximize over `(k', l)`:
   ```
   V(k, z) = max_{k', l} { u(c, l) + beta * E[V(k', z') | z] }
   ```
2. Intratemporal FOC for labor: `chi * l^(1/eta) = w * c^(-sigma)` → solve for `l` given `c` and `w`
3. Use the FOC to reduce the problem to a single choice variable `k'`

### Calibrate chi
- At steady state: `chi = w_ss * C_ss^(-sigma) / L_ss^(1/eta)` with `L_ss = 1`

### Benchmark Values
| Variable | Value |
|----------|-------|
| `E[L]` | ≈ 1.0 |
| `std(L)` | > 0 (labor responds to TFP shocks) |
| `corr(L, Y)` | > 0 (procyclical labor) |
| `std(Y)` | > v1's `std(Y)` (labor amplifies TFP shocks) |

### Validation
- `L_ss = 1` in the deterministic steady state
- Labor is procyclical: higher `z` → higher `l`
- Output volatility is amplified relative to v1 (labor channel)
