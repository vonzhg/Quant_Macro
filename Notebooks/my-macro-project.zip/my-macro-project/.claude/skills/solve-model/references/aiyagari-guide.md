# Aiyagari Model — Algorithm Reference

## Model Environment

- Continuum of agents, infinite horizon
- Preferences: `u(c) = c^(1-sigma) / (1-sigma)`, `sigma = 2`
- Technology: `Y = K^alpha * L^(1-alpha)`, `alpha = 0.36`, `delta = 0.08`
- Discount factor: `beta = 0.96`
- Idiosyncratic income: `log(y)` follows AR(1), `rho_y = 0.9`, `sigma_y = 0.2`
- Borrowing constraint: `a >= a_min = 0` (natural borrowing limit or zero)
- No aggregate uncertainty

---

## Version 0: Deterministic Savings Problem

### Description
A single agent with constant income `y = 1`. No uncertainty. This tests the grid, VFI algorithm, and convergence before adding complexity.

### Budget Constraint
```
c + a' = (1 + r) * a + w
```
where `r` and `w` are fixed at their steady-state values.

### Steady-State Prices (from firm FOCs with K/L ratio)
For given `r`, the firm FOCs give:
```
K/L = (alpha / (r + delta))^(1/(1-alpha))
w   = (1-alpha) * (K/L)^alpha
```

Use `r = 1/beta - 1 - 0.001 = 0.03042` (slightly below `1/beta - 1` to ensure finite wealth).

### Algorithm: Value Function Iteration
1. Asset grid: `N_a = 200` points from `a_min = 0` to `a_max = 50`
   - Use triple-exponential spacing for more points near `a_min`:
     ```python
     x = np.linspace(0, 1, N_a)
     a_grid = a_min + (a_max - a_min) * x**3
     ```
2. Initialize `V(a) = u((1+r)*a + w) / (1 - beta)` (consume-everything value)
3. For each `a` on the grid, solve:
   ```
   V(a) = max_{a' >= a_min} { u((1+r)*a + w - a') + beta * V(a') }
   ```
4. Interpolate `V(a')` using the grid (linear interpolation via `np.interp`)
5. Convergence: `sup |V_new - V_old| < 1e-8`

### Benchmark Values
| Variable | Value |
|----------|-------|
| `a_ss` | Analytical: solve `(1+r)*a + w - a = c_ss` → agent holds constant `a` |
| Euler | `u'(c_ss) = beta*(1+r)*u'(c_ss)` → holds when `beta*(1+r) = 1` |
| Policy | `a'(a)` crosses 45-degree line at `a_ss` |

### Validation
- Policy function crosses 45-degree line exactly once (unique steady state)
- `a'(a) < a` for `a > a_ss` and `a'(a) > a` for `a < a_ss` (stable dynamics)
- Convergence in < 500 iterations with Howard improvement
- Plot: `a'(a)` vs `a` with 45-degree line

---

## Version 1: Idiosyncratic Income Risk

### Changes from v0
- Income is stochastic: `log(y') = rho_y * log(y) + epsilon`, `epsilon ~ N(0, sigma_eps^2)`
- `rho_y = 0.9`, `sigma_eps = 0.2` (so `sigma_y = sigma_eps / sqrt(1-rho_y^2) ≈ 0.459`)
- State is now `(a, y)` — two-dimensional
- Agent solves:
  ```
  V(a, y) = max_{a' >= a_min} { u((1+r)*a + w*y - a') + beta * E[V(a', y') | y] }
  ```

### Income Process Discretization (Tauchen Method)
- Number of states: `N_y = 5`
- Span: `m = 3` standard deviations
- Grid: `log_y_grid` evenly spaced from `-m * sigma_y` to `+m * sigma_y`
- `y_grid = exp(log_y_grid)` — normalize so `mean(y * pi_stationary) ≈ 1`
- Transition matrix `Pi[i,j]`: probability of moving from `y_i` to `y_j`
- Stationary distribution `pi_stationary`: eigenvector of `Pi'` with eigenvalue 1

### Algorithm
1. Grids: `N_a = 200` (same as v0), `N_y = 5`
2. State space: `(a_grid[i], y_grid[j])` for `i=0,...,N_a-1` and `j=0,...,N_y-1`
3. Value function: `V[i, j]` — initialize from v0 solution (broadcast across `y`)
4. For each `(a_i, y_j)`, solve:
   ```
   V(a_i, y_j) = max_{a' >= a_min} { u((1+r)*a_i + w*y_j - a') + beta * sum_k Pi[j,k] * V_interp(a', y_k) }
   ```
5. Use vectorized maximization: for each `(a_i, y_j)`, compute the RHS for all candidate `a'` on the grid and take the max
6. Convergence: `sup |V_new - V_old| < 1e-8`
7. Howard improvement: every 25 VFI iterations, do 50 Howard steps

### Benchmark Values
| Variable | Expected |
|----------|----------|
| Policy shape | `a'(a, y)` increasing in both `a` and `y` |
| Borrowing constraint | Low-income agents hit `a_min` — flat region in `a'(a, y_low)` |
| Euler residuals | Max absolute < 1e-4 at non-constrained points |
| Precautionary savings | Mean `a` > deterministic `a_ss` (agents save more due to risk) |

### Validation
- Policy function is weakly increasing in `a` for each `y`
- Policy function is weakly increasing in `y` for each `a`
- Borrowing constraint binds for low `(a, y)` — verify `a'(a_min, y_low) = a_min`
- Euler equation residuals < 1e-4 at interior (non-constrained) points
- Plots: policy functions `a'(a)` for each income level, consumption policy `c(a)` for each income level

---

## Version 2: Stationary Distribution and General Equilibrium

### Changes from v1
- Compute the stationary distribution `mu(a, y)` over the state space
- Close the model in general equilibrium: find `r` such that asset market clears
- Capital supply = aggregate savings from households
- Capital demand = firm's optimal capital given `r`

### Stationary Distribution
Given policy function `a'(a, y)` and transition matrix `Pi`:

**Method: Eigenvalue approach on discretized transition matrix**
1. Build the grand transition matrix `T` of size `(N_a * N_y) x (N_a * N_y)`
2. For state `(a_i, y_j)` with policy `a' = a_pol[i,j]`:
   - Find the two grid points `a_grid[l]` and `a_grid[l+1]` that bracket `a'`
   - Weight: `omega = (a_grid[l+1] - a') / (a_grid[l+1] - a_grid[l])`
   - For each `y_k`: `T[(i,j) -> (l,k)] += omega * Pi[j,k]` and `T[(i,j) -> (l+1,k)] += (1-omega) * Pi[j,k]`
3. Find stationary distribution: `mu` is the eigenvector of `T'` with eigenvalue 1
4. Normalize: `sum(mu) = 1`

### General Equilibrium
1. Outer loop over `r`:
   - Given `r`, compute `w` from firm FOCs
   - Solve household problem (v1 algorithm) → get `a_pol(a, y)`
   - Compute stationary distribution `mu(a, y)`
   - Compute capital supply: `K_s = sum_{a,y} a * mu(a, y)`
   - Compute capital demand: `K_d = (alpha / (r + delta))^(1/(1-alpha)) * L` where `L = sum_{y} y * pi_stationary(y)`
   - Excess supply: `ES(r) = K_s - K_d`
2. Find `r*` such that `ES(r*) = 0` using bisection on `[r_low, r_high]`
   - `r_low = -delta + 0.001` (near-zero interest rate)
   - `r_high = 1/beta - 1 - 0.001` (just below complete-markets rate)
   - Bisection tolerance: `|ES| < 1e-4` or `|r_high - r_low| < 1e-6`

### Benchmark Values (Aiyagari 1994, Table 1 approximation)
| Variable | Expected |
|----------|----------|
| `r*` | Below `1/beta - 1 ≈ 0.0417`; typically around `0.01` to `0.03` depending on parameters |
| `K/Y` | Around 3.0 (annualized) |
| `Gini(a)` | > 0 (wealth inequality, typically 0.3–0.6) |
| `frac(a = a_min)` | > 0 (positive mass at borrowing constraint) |
| Market clearing | `|K_s - K_d| < 1e-4` |

### Validation
- `sum(mu) = 1` within machine precision (1e-10)
- `mu >= 0` everywhere
- Market clearing: `|K_s - K_d| < 1e-4`
- `r* < 1/beta - 1` (incomplete markets → capital overaccumulation → lower r)
- Positive mass at borrowing constraint (some agents are constrained)
- Wealth Lorenz curve is below the 45-degree line
- Comparative statics: higher `sigma_eps` → lower `r*` (more precautionary savings)
- Plots: stationary distribution (histogram), Lorenz curve, policy functions at equilibrium prices
