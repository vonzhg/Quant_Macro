---
name: Solve Model
description: Iterative model building — design, implement, validate, extend
user_invocable: true
command: solve-model
arguments:
  - name: model
    description: Which model to solve (e.g., aiyagari, rbc)
    required: true
  - name: version
    description: Target version (v0, v1, v2)
    required: true
---

# Solve Model Skill

Build economic models iteratively: start simple, validate, extend. Each version adds one feature and must pass all benchmarks before proceeding.

## Steps

### 1. Design Algorithm
- Read the reference file for the target model (`references/{model}-guide.md`)
- Identify what this version adds relative to the previous version
- Write down the key equations and solution algorithm
- Save a plan to `quality_reports/plans/plan-{version}-{description}.md`

### 2. Implement with Diagnostics
- Write the script in `scripts/{model}_{version}.py`
- Follow conventions in `rules/code-conventions.md`
- Include convergence diagnostics: iteration count, sup-norm, elapsed time
- Include benchmark comparisons: print expected vs actual values
- Save results to `output/{model}_{version}_results.npz`
- Save figures to `output/{model}_{version}_*.png`

### 3. Validate
- Run the verifier agent to execute the script
- Check all benchmarks for this version (see reference file)
- Run the domain reviewer to verify economic correctness
- Run the code reviewer to check code quality
- All must pass before proceeding

### 4. Extend
- Only after validation passes, move to the next version
- The next version builds on the current one — import shared utilities
- Identify what changes: new state variables, new equations, new equilibrium conditions

### 5. Repeat
- Go back to step 1 for the next version
- Each version follows the same cycle: Design → Implement → Validate → Extend

## Available References

| Model | Reference File | Versions |
|-------|---------------|----------|
| RBC | `references/rbc-guide.md` | v0: deterministic, v1: stochastic TFP, v2: variable labor |
| Aiyagari | `references/aiyagari-guide.md` | v0: deterministic savings, v1: income risk, v2: stationary distribution |

## Example Usage

To solve the Aiyagari model starting from v0:
```
/solve-model aiyagari v0
```

This will:
1. Read `references/aiyagari-guide.md` for the v0 specification
2. Create a plan in `quality_reports/plans/`
3. Implement `scripts/aiyagari_v0.py`
4. Run verification and review
5. Report results and readiness for v1
