# MEMORY.md — Accumulated Learnings

> **Format:** Each entry uses `[LEARN:tag]` so Claude can search by topic.
> Append new learnings at the bottom. Never delete old entries — they form project history.

---

[LEARN:aiyagari-grid] Asset grid for Aiyagari model should use more points near the borrowing constraint. A grid of 200 points with triple-exponential spacing works well. Linear grids need 500+ points for comparable accuracy.

[LEARN:vfi-howard] Howard improvement (policy iteration acceleration) cuts VFI iterations by ~80%. After every 25 VFI iterations, run 50 Howard steps. Convergence tolerance: 1e-8 on the sup-norm of the value function difference.

[LEARN:notation] Project notation convention — `V` for value function, `c_pol` for consumption policy, `a_pol` for savings policy, `Pi` for transition matrix, `mu` for stationary distribution. State variables: `(a, y)` where `a` is assets, `y` is income.
