# CLAUDE.md — Aiyagari Model Project

## Project Overview

This is a quantitative macroeconomics project for **AI & ML for Quant Macro**. We solve the Aiyagari (1994) incomplete-markets model using an iterative build-up approach: start simple, validate, extend.

**Language:** Python (NumPy/SciPy)
**Philosophy:** Never skip validation between versions. Every model version must pass benchmarks before extending.

## Folder Structure

```
my-macro-project/
├── CLAUDE.md                 ← You are here (project brain)
├── MEMORY.md                 ← Learnings accumulated across sessions
├── .claude/
│   ├── settings.json         ← Permissions and tool config
│   ├── skills/
│   │   ├── solve-model/      ← Main model-building skill
│   │   │   ├── SKILL.md
│   │   │   └── references/
│   │   │       ├── rbc-guide.md
│   │   │       └── aiyagari-guide.md
│   │   └── validate/         ← Validation and benchmarking skill
│   │       └── SKILL.md
│   ├── agents/
│   │   ├── code-reviewer.md      ← Code quality checks
│   │   ├── domain-reviewer.md    ← Economic correctness checks
│   │   └── verifier.md           ← Runs and tests code
│   └── rules/
│       ├── plan-first-workflow.md
│       ├── orchestrator-protocol.md
│       ├── iterative-workflow.md
│       ├── verification-protocol.md
│       └── code-conventions.md
├── scripts/                  ← Python source code
├── output/                   ← Figures, tables, saved results
└── quality_reports/
    └── plans/                ← Session plans and logs
```

## Available Skills

| Skill | Command | Purpose |
|-------|---------|---------|
| Solve Model | `/solve-model` | Iterative model building: design → implement → validate → extend |
| Validate | `/validate` | Run benchmarks, check convergence, Euler equation residuals |

## Available Agents

| Agent | File | Mode | Purpose |
|-------|------|------|---------|
| Code Reviewer | `code-reviewer.md` | READ-ONLY | Vectorization, numerical stability, reproducibility |
| Domain Reviewer | `domain-reviewer.md` | READ-ONLY | Equilibrium conditions, benchmark values, economic intuition |
| Verifier | `verifier.md` | EXECUTE | Runs scripts, checks convergence, validates output |

## Active Rules

1. **Plan-First Workflow** — Plan before coding for non-trivial tasks
2. **Orchestrator Protocol** — Implement → Verify → Review → Fix → Score loop
3. **Iterative Workflow** — Version 0 → 1 → 2 build-up; never skip validation
4. **Verification Protocol** — Always run code before reporting results
5. **Code Conventions** — Seeds, no hardcoded paths, meaningful names, save to `output/`

## Model Versions

| Version | Description | Key Feature |
|---------|-------------|-------------|
| v0 | Deterministic savings | Single agent, no uncertainty, analytical steady state |
| v1 | Income risk | Idiosyncratic income shocks, Tauchen discretization |
| v2 | Stationary distribution | Eigenvalue method, general equilibrium, market clearing |

## Working Conventions

- Read `MEMORY.md` at the start of each session for accumulated learnings
- When you learn something worth preserving, append it to `MEMORY.md` using the `[LEARN:tag]` format
- Always follow the iterative workflow: simple version first, validate, then extend
- Reference files in `skills/solve-model/references/` contain algorithm specs — consult them before implementing
- Save all code to `scripts/`, all output to `output/`, all plans to `quality_reports/plans/`
