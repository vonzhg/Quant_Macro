# my-macro-project

A Claude Code project for solving the Aiyagari (1994) incomplete-markets model, built for **Econ 730: Quantitative Macroeconomics**.

The project uses Claude Code's skills, agents, and rules to enforce an iterative workflow: **start simple, validate, extend.**

## Quick Start

```bash
cd ~/Github/my-macro-project
claude
```

Claude automatically reads `CLAUDE.md` and loads all rules, agents, and skills. Then build the model version by version:

```
/solve-model aiyagari v0    # Deterministic savings problem
/solve-model aiyagari v1    # Add idiosyncratic income risk
/solve-model aiyagari v2    # Stationary distribution + general equilibrium
```

Each version must pass validation before you can proceed to the next.

## Skills (Slash Commands)

| Command | What it does |
|---------|-------------|
| `/solve-model aiyagari v0` | Design algorithm, implement, validate, report readiness for next version |
| `/validate aiyagari v1` | Run benchmarks, check convergence, Euler residuals, economic correctness |

You can also just talk naturally — *"implement the deterministic savings problem"* or *"why isn't my value function converging?"* — and the rules guide Claude's behavior automatically.

## How the Pieces Fit Together

```
You ──► /solve-model aiyagari v0
             │
             ▼
        ┌─────────────────────────────┐
        │  SKILL: solve-model         │
        │  1. Read references/        │◄── Algorithm specs, equations,
        │  2. Write plan              │    benchmark values
        │  3. Implement script        │
        │  4. Validate                │
        └──────────┬──────────────────┘
                   │
        ┌──────────▼──────────────────┐
        │  ORCHESTRATOR LOOP          │
        │  Implement → Verify → Review│◄── Rules enforce this automatically
        │  → Fix → Score              │
        └──────────┬──────────────────┘
                   │
          ┌────────┼────────┐
          ▼        ▼        ▼
      Verifier  Code Rev  Domain Rev    ◄── Agents (run behind the scenes)
      (execute) (read)    (read)
```

## Project Structure

```
my-macro-project/
├── CLAUDE.md                          # Project brain — Claude reads this first
├── MEMORY.md                          # Learnings persisted across sessions
├── README.md                          # You are here
├── .claude/
│   ├── settings.json                  # Permissions for Python, git, etc.
│   ├── skills/
│   │   ├── solve-model/
│   │   │   ├── SKILL.md              # Iterative model-building workflow
│   │   │   └── references/
│   │   │       ├── aiyagari-guide.md # Equations, parameters, benchmarks
│   │   │       └── rbc-guide.md      # Same for the RBC model
│   │   └── validate/
│   │       └── SKILL.md              # Benchmark and validation workflow
│   ├── agents/
│   │   ├── code-reviewer.md          # Checks vectorization, stability, style
│   │   ├── domain-reviewer.md        # Checks equations, equilibrium, intuition
│   │   └── verifier.md               # Runs code, checks convergence, no NaN
│   └── rules/
│       ├── iterative-workflow.md     # v0 → v1 → v2, never skip validation
│       ├── orchestrator-protocol.md  # Implement → Verify → Review → Fix loop
│       ├── plan-first-workflow.md    # Plan before coding non-trivial tasks
│       ├── verification-protocol.md  # Always run code before reporting results
│       └── code-conventions.md       # Seeds, naming, output conventions
├── scripts/                           # Python code goes here
├── output/                            # Figures, tables, saved results
└── quality_reports/
    └── plans/                         # Session plans and validation reports
```

## What Each Piece Does

| Piece | Role | You interact with it? |
|-------|------|----------------------|
| **CLAUDE.md** | Tells Claude about the project — structure, conventions, what's available | No — Claude reads it automatically |
| **MEMORY.md** | Persists learnings across sessions (`[LEARN:tag]` format) | Claude updates it; you can read/edit |
| **Skills** | Slash commands that trigger structured workflows | Yes — you invoke `/solve-model`, `/validate` |
| **Agents** | Specialized reviewers Claude delegates to | No — Claude uses them behind the scenes |
| **Rules** | Behavioral guardrails that apply automatically | No — they shape how Claude works |
| **References** | Algorithm specs with Bellman equations, parameters, benchmarks | No — Claude consults them when building |

## Model Versions

### Aiyagari Model

| Version | Description | Validation Gate |
|---------|-------------|-----------------|
| v0 | Deterministic savings — single agent, no uncertainty | Steady state matches analytical formula within 1e-6 |
| v1 | Income risk — idiosyncratic shocks, Tauchen discretization | Policy monotone; Euler residuals < 1e-4 |
| v2 | Stationary distribution — eigenvalue method, GE market clearing | Distribution sums to 1; market clearing < 1e-4 |

### RBC Model

| Version | Description | Validation Gate |
|---------|-------------|-----------------|
| v0 | Deterministic steady state (analytical) | Values match closed-form formulas |
| v1 | Stochastic TFP — AR(1) productivity, VFI | Mean capital ≈ deterministic K_ss |
| v2 | Variable labor supply — intratemporal FOC | L_ss = 1; labor is procyclical |

## Key Parameters (Aiyagari)

| Parameter | Symbol | Value |
|-----------|--------|-------|
| Risk aversion | σ | 2 |
| Capital share | α | 0.36 |
| Depreciation | δ | 0.08 |
| Discount factor | β | 0.96 |
| Income persistence | ρ_y | 0.9 |
| Income shock std | σ_ε | 0.2 |
| Borrowing limit | a_min | 0 |

## Requirements

- Python 3 with NumPy, SciPy, Matplotlib
- [Claude Code](https://docs.anthropic.com/en/docs/claude-code)
